
 <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo base_url('assets/jquery-easing/jquery.easing.min.js'); ?>"></script>

  <!-- Contact form JavaScript -->
  <script src="<?php echo base_url('js/jqBootstrapValidation.js'); ?>"></script>
  <script src="<?php echo base_url('js/contact_me.js'); ?>"></script>

  <!-- Custom scripts for this template -->
  <script src="<?php echo base_url('js/agency.min.js'); ?>"></script>